# Thái Bảo Lighting — Website bán hàng

## Cấu trúc project
```
thaibao-lighting/
├── index.html
├── package.json
├── vite.config.js
├── vercel.json
├── public/
│   └── favicon.svg
└── src/
    ├── main.jsx
    └── App.jsx
```

## Deploy lên Vercel (miễn phí)

### Bước 1 — Cài Node.js
Tải tại: https://nodejs.org (chọn LTS)

### Bước 2 — Cài Vercel CLI
Mở CMD/Terminal, gõ:
```
npm install -g vercel
```

### Bước 3 — Deploy
Vào thư mục project:
```
cd thaibao-lighting
npm install
vercel
```
Đăng nhập bằng Google → làm theo hướng dẫn → website lên mạng!

### Bước 4 — Gắn tên miền thaibaolighting.com
1. Vào dashboard.vercel.com → chọn project
2. Settings → Domains → Add Domain
3. Nhập: thaibaolighting.com
4. Copy DNS records → vào PA Vietnam → cập nhật DNS

## Hotline hỗ trợ
0935 351 095
